﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcWebUI.Models
{
    public class ShippingDetailsViewModel
    {
        public ShippingDetail ShippingDetail { get; set; }
    }
}
