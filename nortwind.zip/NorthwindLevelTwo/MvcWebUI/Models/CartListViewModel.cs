﻿using Entities.DomainModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcWebUI.Models
{
    public class CartListViewModel
    {
        public Cart Cart { get; set; }
    }
}
